package Stack;

public class poppush 
{
	int top;
	int arr[]  = new int[5];
	boolean isEmpty() 
	{
		return (top<0);
	}
	poppush ()
	{
		top=-1;
	}
	boolean push(int n) 
	{
		if(top==arr.length-1) 
		{
			System.out.println("stack overflow");
			return false;
		}
		else 
		{
			top++;
			arr[top]=  n;
			System.out.println("value pushed "+n);
			return true;
		}
		
		
	}
	  boolean pop ()  
	    {  
	        if (top == -1)  
	        {  
	            System.out.println("Underflow !!");  
	            return false;  
	        }  
	        else   
	        {  
	        	System.out.println("Item popped "+arr[top]);  
	            top --;   
	            
	            return true;  
	        }  
	    }  

	public static void main(String[] args) {
		poppush obj = new poppush();
		obj.push(5);
		obj.push(6);
		obj.push(15);
		obj.push(10);
		obj.pop();

	}

}
