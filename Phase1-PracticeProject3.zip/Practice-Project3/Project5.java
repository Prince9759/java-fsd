package SingleLL;

public class duplicateDelete {
      Node head;
	static class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data =data;
			this.next = null;
		}
	}
	void push(int data) 
	{
		Node newnode  =  new Node(data);
		newnode.next=head;
		head = newnode;
	}
	void print() 
	{
		Node cur = head;
		while(cur!=null) 
		{
			System.out.print(cur.data+"->");
			cur   =cur.next;
		}
	}
	void delete() 
	{
		Node cur=head,prev=null;
		int key=4;
		if(cur!=null && cur.data==key) 
		{
			head = cur.next;
		}
		while(cur!=null && cur.data!=key) 
		{
			prev=cur;
			cur=cur.next;
		}
		if(cur==null) 
		{
			return ;
			
		}
		prev.next=cur.next;
		
	}
	public static void main(String[] args) 
	{
		duplicateDelete obj  = new duplicateDelete();
		obj.push(4);
		obj.push(6);
		obj.push(3);
		obj.push(4);
		obj.push(2);
		obj.push(3);
		System.out.println("print element before delete");
		obj.print();
		obj.delete();
System.out.println();
		System.out.println("print element after delete the first occurence of 4");
		obj.print();
		

	}

}
