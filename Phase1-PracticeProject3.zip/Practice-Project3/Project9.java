package queue;
import java.util.*;
public class queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> q = new LinkedList<>();
		q.add(1);
		q.add(5);
		q.add(3);
		q.add(10);
		q.add(15);
		System.out.println("element insert in the queue the queue "+q);
		System.out.println("size of the queue before deleted element "+q.size());
		System.out.println("head element of the queue "+q.peek());
		System.out.println("deleted element from the queue "+q.remove());
		System.out.println("size of the queue after deleted element "+q.size());
		
		

	}

}
