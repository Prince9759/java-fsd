package multiply2matrix;

public class matrix {

	public static void main(String[] args) {
		int arr[][] = {{3,-2,5},{3,0,4}};
        int a[][] = {{2,3},{-9,0},{0,4}};
        
        int c[][]=new int[arr.length][a[0].length];   
        
         
      for(int i=0;i<arr.length;i++){    
      for(int j=0;j<a[0].length;j++){    
      c[i][j]=0;      
      for(int k=0;k<arr[0].length;k++)      
      {      
      c[i][j]+=arr[i][k]*a[k][j];      
      }  
      System.out.print(c[i][j]+" ");  
      } 
      System.out.println();
      }}}