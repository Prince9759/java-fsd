package typecasting;

public class TypeCasting {

	public static void main(String[] args) {
		System.out.println("Implicit Type Casting");

		char x='m';
      System.out.println("Value of a: "+x);
		
		int b=x;
		System.out.println("Value of b: "+b);
		
		float c=x;
		System.out.println("Value of c: "+c);
		
		long d=x;
		System.out.println("Value of d: "+d);
		
		double e=x;
		System.out.println("Value of e: "+e);
		
				
		System.out.println("\n");

		System.out.println("explicit Type Casting");

		double m=5.5;
		System.out.println("value of m: "+m);
		int n = (int)m;
		System.out.println("value of n: "+n);
		char z= (char)m;
		System.out.println("value of z: "+ z);
		
		
		

	}

}