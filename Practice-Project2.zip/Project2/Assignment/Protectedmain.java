package Assignment;

import abc.*;

public class Protectedmain extends ProtectedA{

	public static void main(String[] args) {
	 Protectedmain obj  =  new Protectedmain();
	 obj.msg();

	}

}

