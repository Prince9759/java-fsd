package Assignment;

class A
{
    void msg() 
    {
    	System.out.println("deafult is used");
    }
}
public class DefaultMain {
	public static void main(String args[]) 
	{
		A obj  =  new A();
		obj.msg();
	}

}
