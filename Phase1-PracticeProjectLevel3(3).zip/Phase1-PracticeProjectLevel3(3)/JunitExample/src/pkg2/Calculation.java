package pkg2;
public class Calculation {
	public int addition(int num1, int num2) {
		return num1+num2;
	}
}