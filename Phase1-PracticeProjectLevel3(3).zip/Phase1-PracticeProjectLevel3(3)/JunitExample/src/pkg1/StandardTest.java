package pkg1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;


@DisplayName("Junit 5 standard Test Class Example")

public class StandardTest 
{
	@BeforeAll
	public static void beforeall() 
	{
		System.out.println("before all test cases");
	}
	

	@BeforeEach
	public  void beforeeach() 
	{
		System.out.println("before each test cases");
	}
    @DisplayName("Standard Test")
	@Test
	public  void test() 
	{
		System.out.println("test case 1");
	}

    @Test
	public  void test1() 
	{
		System.out.println("test case 2");
	}
    @AfterEach
	public  void aftereach() 
	{
		System.out.println("after each");
	}
    
    @org.junit.jupiter.api.AfterAll

	public static void AfterAll() 
	{
		System.out.println("after all");
	}
    
    @Disabled
    @Test
    public  void skippedTest()
    {
    	System.out.println("Skipped test case");
    }
}
