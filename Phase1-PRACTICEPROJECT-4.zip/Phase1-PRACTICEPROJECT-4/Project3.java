package Project4;

import java.util.*;

public class Project3 
{
	static int expSearch(int arr[], int n, int search) {
		 
		  if(arr[0] == search) {
		   return 0;
		  }
		  
		  int i = 1;
		  while (i < n && arr[i] <= search) {
		   i = i * 2;
		  }
		  
		  return Arrays.binarySearch(arr, (i / 2), Math.min(i, n), search);
		}


	public static void main(String[] args) {
		int arr[]= {100,200,300,400,500};
		Arrays.sort(arr);
		Scanner sc  =  new Scanner(System.in);
         System.out.println("enter number you want to search");
         int n  =  sc.nextInt();
		   int result = expSearch(arr, arr.length, n);
		   if(result<0) 
		   {
			   System.out.println("not Present");
		   }
		   else {
		   System.out.println("Element is present at index: " + result);}
		  }
		}
