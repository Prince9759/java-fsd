package Project4;

import java.util.Arrays;
import java.util.Scanner;

public class Project2 {
 public static int Bineary(int arr[],int l,int r,int s) 
 {
	 if(l<=r) 
	 {
		 int mid  = l+(r-l)/2;
		 if(arr[mid]==s) 
		 {
			 return mid;
		 }
		 if(arr[mid]>s) 
		 {
			 return  Bineary(arr,l,mid-1,s);
		 }
		  return Bineary(arr,mid+1,r,s);
	 }
	 return -1;
 }
	public static void main(String[] args) {
		int arr[]= {100,200,300,400,500};
		Arrays.sort(arr);
		Scanner sc  =  new Scanner(System.in);
         System.out.println("enter number you want to search");
         int n  =  sc.nextInt();
       int result=  Bineary(arr,0,arr.length-1,n);
         if(result==-1) 
         {
        	 System.out.println("not Present");
         }
         else 
         {
        	 System.out.println(" Present");
         }

	}

}
