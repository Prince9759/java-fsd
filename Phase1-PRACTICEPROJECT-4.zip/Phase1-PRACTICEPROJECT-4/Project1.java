package Project4;
import java.util.*;
public class Project1 {
   public static void linear(int arr[],int n) 
   {
	   int c=0;
	   for(int i=0;i<arr.length;i++) 
	   {
		   if(n==arr[i]) 
		   {
			   c++;
		   }
		 
	   }
	   if(c>0) 
	   {
		   System.out.println("element Present");
	   }
	   else 
	   {
		   System.out.println("not Present");
	   }
   }
	public static void main(String[] args) {
		int arr[]= {100,200,300,400,500};
		Scanner sc  =  new Scanner(System.in);
         System.out.println("enter number you want to search");
         int n  =  sc.nextInt();
         linear(arr,n);
	}

}
